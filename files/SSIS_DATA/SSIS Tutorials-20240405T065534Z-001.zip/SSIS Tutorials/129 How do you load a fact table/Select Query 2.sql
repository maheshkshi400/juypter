SELECT top 1 * FROM [FameSell].[dbo].[Orders]
select top 1 * from [Dimension].[Customer]
select top 1 * from [Dimension].[Employee]
select top 1 * from [Dimension].[Product]
select top 1 * from [Dimension].[Date]
SELECT * FROM [FameSellDW].[Fact].[Orders]

