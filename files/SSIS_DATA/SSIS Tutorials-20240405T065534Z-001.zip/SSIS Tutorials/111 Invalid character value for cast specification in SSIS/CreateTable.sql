CREATE TABLE [dbo].[Emp](
	[id] [int] NULL,
	[first_name] [varchar](50) NULL,
	[last_name] [varchar](50) NULL,
	[DateOfJoining] [date] NULL
) ON [PRIMARY]
GO