create index ix_id on testdata(id)
go
create index ix_first_name on testdata(first_name)
-----------------------------------------------------------
create index ix_last_name on testdata(last_name)
go
create index ix_Gender on testdata(Gender)
go
----------------------------------------------------------------
create index ix_Company_Name on testdata(Company_Name)
go
create index ix_FNLN on testdata(First_Name,Last_Name)
go
