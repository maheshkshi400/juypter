/*
truncate table TestData
truncate table tbllogs
*/
select count(*) from TestData
select * from tblLogs