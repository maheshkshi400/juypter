drop table DNCFlag
go
create table DNCFlag(Id int, Active bit)
go
select * from DNCFlag