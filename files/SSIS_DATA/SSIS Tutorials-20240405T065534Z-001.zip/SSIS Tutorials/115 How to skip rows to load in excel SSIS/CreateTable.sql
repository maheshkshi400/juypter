CREATE TABLE [dbo].[Email](
	[id] [int] NULL,
	[first_name] [nvarchar](50) NULL,
	[last_name] [nvarchar](50) NULL,
	[email] [nvarchar](50) NULL,
	[gender] [nvarchar](50) NULL
) ON [PRIMARY]
GO